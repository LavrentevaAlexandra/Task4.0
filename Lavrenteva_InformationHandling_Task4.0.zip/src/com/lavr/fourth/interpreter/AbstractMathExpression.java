package com.lavr.fourth.interpreter;

/**
 * Created by 123 on 09.11.2016.
 */
public abstract class AbstractMathExpression {
    public abstract void interpret(Context context);
}
