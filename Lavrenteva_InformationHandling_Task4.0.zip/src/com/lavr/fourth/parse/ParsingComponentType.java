package com.lavr.fourth.parse;

/**
 * Created by 123 on 13.11.2016.
 */
public enum ParsingComponentType {
    PARAGRAPH, SENTENCE, LEXEME, WORD, SYMBOL
}
